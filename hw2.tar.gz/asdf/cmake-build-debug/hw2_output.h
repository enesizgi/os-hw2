
// the configured options and settings for Tutorial
#define Tutorial_VERSION_MAJOR 
#define Tutorial_VERSION_MINOR 
